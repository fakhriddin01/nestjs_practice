import { Module } from '@nestjs/common';
import { EquipmentService } from './equipment.service';
import { EquipmentController } from './equipment.controller';
import { Equipment } from './models/equipment.model';
import { SequelizeModule } from '@nestjs/sequelize';

@Module({
  imports: [
    SequelizeModule.forFeature([Equipment])
  ],
  controllers: [EquipmentController],
  providers: [EquipmentService],
  exports:[EquipmentService]
})
export class EquipmentModule {}
